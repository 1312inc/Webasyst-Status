<?php

/**
 * Class statusCheckinProjectsModel
 */
class statusCheckinProjectsModel extends statusModel
{
    protected $table = 'status_checkin_projects';
}
