<?php

return [
    [
        'event_app_id' => 'webasyst',
        'event' => 'backend_header',
        'class' => 'statusAutoTraceEventSubscriber',
        'method' => ['handleWebasystBackendHeader'],
    ],
];
