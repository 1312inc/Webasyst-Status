<?php
return array(
    'php' => array(
        'strict'  => true,
        'version' => '>=7.1',
    ),
    'app.installer' => array(
        'version' => '>=2.2.0',
        'strict'  => true,
    ),
);
