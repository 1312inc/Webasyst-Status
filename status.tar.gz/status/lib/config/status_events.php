<?php

return [
    statusEventStorage::ENTITY_DELETE_BEFORE => [
        ['statusProjectEventListener', 'beforeDelete'],
        ['statusCheckinEventListener', 'beforeDelete'],
    ],
];
