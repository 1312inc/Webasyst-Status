<?php
return array (
  'name' => 'Status',
  'icon' => 'img/status.png',
  'version' => '2.0.0',
  'vendor' => '1021997',
  'rights' => true,
  'ui' => '1.3,2.0',
);
