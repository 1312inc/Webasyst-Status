<?php

/**
 * Class statusJsonController
 */
abstract class statusJsonController extends kmwaWaJsonController
{
}
