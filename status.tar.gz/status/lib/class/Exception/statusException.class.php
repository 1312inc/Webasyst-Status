<?php

/**
 * Class statusException
 */
class statusException extends waException
{

}
