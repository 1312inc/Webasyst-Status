<?php

/**
 * Class statusModel
 */
class statusModel extends waModel
{

}
