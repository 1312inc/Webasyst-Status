<?php

/**
 * Class statusSettingsUser
 */
class statusSettingsUser
{
    const WEEK_WORKING_HOURS  = 40;
}
