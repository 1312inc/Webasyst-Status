<?php

/**
 * Class statusEvent
 */
class statusEvent extends kmwaEvent
{

}
